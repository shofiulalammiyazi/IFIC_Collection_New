create FUNCTION                        "FXN_GET_CUSTOMER_INFO" (P_CUSTOMERNO  VARCHAR2) 
    RETURN SYS_REFCURSOR
IS
    p_recordset SYS_REFCURSOR;
BEGIN 
  OPEN p_recordset FOR
    select * FROM customer_personal_info where CUST_NO = P_CUSTOMERNO;
    RETURN p_recordset;
END FXN_GET_CUSTOMER_INFO;

/

